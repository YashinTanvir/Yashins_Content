﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

// Defining interface for basic bank services with polymorphism
public interface INetWealthServices
{
    // Defining methods for account actions
    void ViewBalance();
    void Deposit(decimal amount);
    void Withdraw(decimal amount);
    void Transfer(string toUsername, decimal amount, Dictionary<string, User> users);
}

// Implementing User class with INetWealthServices interface to allow polymorphism
public class User : INetWealthServices
{
    // Defining user properties and private password hash (encapsulation)
    public string Username { get; }
    public string Email { get; }
    public int Age { get; }
    public string Phone { get; }
    private string PasswordHash { get; set; }

    protected decimal Balance { get; set; }

    // Initializing User with properties, ensuring password hash is encapsulated
    public User(string username, string email, int age, string phone, string passwordHash)
    {
        Username = username;
        Email = email;
        Age = age;
        Phone = phone;
        PasswordHash = passwordHash;
        Balance = 0;  // Setting initial balance to zero
    }

    // Validating password by comparing stored hash with entered password hash
    public bool ValidatePassword(string password) => PasswordHash == Bank.HashPassword(password);

    // Updating password securely by hashing and storing it
    public void UpdatePassword(string newPassword)
    {
        PasswordHash = Bank.HashPassword(newPassword);
    }

    // Displaying the current balance
    public virtual void ViewBalance()
    {
        Console.WriteLine($"Balance for {Username}: ${Balance}");
    }

    // Adding deposit amount to balance
    public virtual void Deposit(decimal amount)
    {
        Balance += amount;
        Console.WriteLine($"Deposited ${amount}. New balance is ${Balance}");
    }

    // Withdrawing amount from balance if funds are sufficient
    public virtual void Withdraw(decimal amount)
    {
        if (amount <= Balance)
        {
            Balance -= amount;
            Console.WriteLine($"Withdrew ${amount}. New balance is ${Balance}");
        }
        else
        {
            Console.WriteLine("Insufficient funds.");
        }
    }

    // Transferring amount to another user if balance is sufficient
    public virtual void Transfer(string toUsername, decimal amount, Dictionary<string, User> users)
    {
        if (users.ContainsKey(toUsername) && amount <= Balance)
        {
            users[toUsername].Deposit(amount);
            Balance -= amount;
            Console.WriteLine($"Transferred ${amount} to {toUsername}. New balance is ${Balance}");
        }
        else
        {
            Console.WriteLine("Transfer failed. Check balance and username.");
        }
    }
}

// Implementing AdminUser class to inherit from User class (Inheritance)
public class AdminUser : User
{
    public const string AdminPassword = "Adminroot";

    // Initializing AdminUser with properties of User
    public AdminUser(string username, string email, int age, string phone, string passwordHash)
        : base(username, email, age, phone, passwordHash) { }

    // Displaying all registered users (Admin functionality)
    public void ViewAllUsers(Dictionary<string, User> users)
    {
        Console.WriteLine("\n--- Registered User ---");
        foreach (var user in users)
        {
            Console.WriteLine($"Username: {user.Value.Username}");
            Console.WriteLine($"Email: {user.Value.Email}");
            Console.WriteLine($"Age: {user.Value.Age}");
            Console.WriteLine($"Phone: {user.Value.Phone}");
            Console.WriteLine("-------------------------");
        }
    }
}

// Creating Bank class to manage users and main program functionalities
public class Bank
{
    // Defining private members for user storage and login attempts (Encapsulation)
    private Dictionary<string, User> users = new Dictionary<string, User>();
    private int loginAttempts = 0;
    private TwoFactorAuth twoFactorAuth = new TwoFactorAuth();

    // Starting the main interface for the bank system
    public void Start()
    {
        while (true)
        {
            Console.WriteLine("\n--- Welcome to NetWealth Bank ---");
            Console.WriteLine("1: Login\n2: Signup\n3: Password Reset\n4: Admin Panel\n5: Quit");
            Console.Write("Select Option: ");
            string option = Console.ReadLine() ?? string.Empty;

            switch (option)
            {
                case "1":
                    Login();
                    break;
                case "2":
                    Signup();
                    break;
                case "3":
                    PasswordReset();
                    break;
                case "4":
                    AdminPanel();
                    break;
                case "5":
                    Console.WriteLine("Thank you for using NetWealth Bank. Goodbye!");
                    Environment.Exit(0); // Terminating program immediately
                    break;
                default:
                    Console.WriteLine("Invalid selection. Please try again.");
                    break;
            }
        }
    }

    // Processing signup with validation and 2FA
    public void Signup()
    {
        Console.WriteLine("\n--- NetWealth Bank Signup ---");

        string username;
        do
        {
            Console.Write("Enter username: ");
            username = Console.ReadLine() ?? string.Empty;
        } while (users.ContainsKey(username)); // Ensuring username is unique

        // Validating email format to end with "@xyz.com"
        string email;
        while (true)
        {
            Console.Write("Enter email: ");
            email = Console.ReadLine() ?? string.Empty;
            if (email.EndsWith("@xyz.com"))
                break;
            else
                Console.WriteLine("Invalid email format. Email must end with '@xyz.com'.");
        }

        // Validating age as a 1–3 digit number
        int age;
        while (true)
        {
            Console.Write("Enter age: ");
            if (int.TryParse(Console.ReadLine(), out age) && age >= 0 && age <= 999)
                break;
            else
                Console.WriteLine("Invalid age. Age must be a 1 to 3 digit number.");
        }

        // Validating phone number to be exactly 10 digits
        string phone;
        while (true)
        {
            Console.Write("Enter phone: +61 ");
            phone = Console.ReadLine() ?? string.Empty;
            if (phone.Length == 9 && long.TryParse(phone, out _))
                break;
            else
                Console.WriteLine("Invalid phone number. Please enter exactly 10 digits.");
        }

        // Validating password for complexity
        string password;
        while (true)
        {
            Console.Write("Enter password: ");
            password = Console.ReadLine() ?? string.Empty;
            if (IsValidPassword(password))
                break;
            else
                Console.WriteLine("Password must contain letters, numbers, and at least one special character.");
        }

        // Verifying 2FA code for signup process
        if (!twoFactorAuth.Verify(email))
        {
            Console.WriteLine("2FA failed. Signup aborted.");
            return;
        }

        // Storing hashed password and saving user
        string hashedPassword = HashPassword(password);
        users[email] = new User(username, email, age, phone, hashedPassword);
        Console.WriteLine("Signup successful!");
    }

    // Processing login with 3 attempts limit and 10-second cooldown
    public void Login()
    {
        if (loginAttempts >= 3)
        {
            Console.WriteLine("Too many failed attempts. Please wait 10 seconds.");

            // Implementing reverse countdown
            for (int i = 10; i > 0; i--)
            {
                Console.Write($"\rTime remaining: {i} seconds ");
                Thread.Sleep(1000);
            }

            Console.WriteLine("\nYou can now try again.");
            loginAttempts = 0; // Resetting attempt counter
        }

        Console.Write("Enter email: ");
        string email = Console.ReadLine() ?? string.Empty;

        Console.Write("Enter password: ");
        string password = Console.ReadLine() ?? string.Empty;

        // Checking if credentials are valid
        if (users.TryGetValue(email, out User user) && user.ValidatePassword(password))
        {
            loginAttempts = 0; // Resetting attempt count on success
            Console.WriteLine($"\nWelcome, {user.Username}!");
            UserMenu(user);
        }
        else
        {
            loginAttempts++;
            Console.WriteLine("Invalid login. Try again.");

            // Triggering cooldown after 3 failed attempts
            if (loginAttempts >= 3)
            {
                Console.WriteLine("Too many failed attempts. Please wait 10 seconds.");

                for (int i = 10; i > 0; i--)
                {
                    Console.Write($"\rTime remaining: {i} seconds ");
                    Thread.Sleep(1000);
                }

                Console.WriteLine("\nYou can now try again.");
                loginAttempts = 0;
            }
        }
    }

    // Managing user account menu actions after login
    private void UserMenu(User user)
    {
        bool isUserMenuActive = true;
        while (isUserMenuActive)
        {
            Console.WriteLine("\n--- User Menu ---");
            Console.WriteLine("1. View Balance\n2. Deposit\n3. Withdraw\n4. Transfer\n5. Quit");
            Console.Write("Select Option: ");
            string option = Console.ReadLine() ?? string.Empty;

            switch (option)
            {
                case "1":
                    user.ViewBalance();
                    break;
                case "2":
                    Console.Write("Enter amount to deposit: ");
                    decimal depositAmount = decimal.Parse(Console.ReadLine() ?? "0");
                    user.Deposit(depositAmount);
                    break;
                case "3":
                    Console.Write("Enter amount to withdraw: ");
                    decimal withdrawAmount = decimal.Parse(Console.ReadLine() ?? "0");
                    user.Withdraw(withdrawAmount);
                    break;
                case "4":
                    Console.Write("Enter recipient username: ");
                    string recipient = Console.ReadLine() ?? string.Empty;
                    Console.Write("Enter amount to transfer: ");
                    decimal transferAmount = decimal.Parse(Console.ReadLine() ?? "0");
                    user.Transfer(recipient, transferAmount, users);
                    break;
                case "5":
                    isUserMenuActive = false;
                    break;
                default:
                    Console.WriteLine("Invalid selection.");
                    break;
            }
        }
    }

    // Providing access to the admin panel for managing users (Admin functionality)
    public void AdminPanel()
    {
        Console.Write("Enter admin password: ");
        string adminPassword = Console.ReadLine() ?? string.Empty;

        if (adminPassword == AdminUser.AdminPassword)
        {
            AdminUser admin = new AdminUser("admin", "admin@xyz.com", 0, "0000000000", HashPassword(AdminUser.AdminPassword));
            admin.ViewAllUsers(users);  // Accessing ViewAllUsers as AdminUser
        }
        else
        {
            Console.WriteLine("Incorrect admin password.");
        }
    }

    // Processing password reset with 2FA verification
    public void PasswordReset()
    {
        Console.Write("Enter registered email: ");
        string email = Console.ReadLine() ?? string.Empty;

        if (users.TryGetValue(email, out User user))
        {
            if (twoFactorAuth.Verify(user.Email))
            {
                Console.Write("Enter new password: ");
                string newPassword = Console.ReadLine() ?? string.Empty;
                user.UpdatePassword(newPassword);
                Console.WriteLine("Password reset successful.");
            }
            else
            {
                Console.WriteLine("2FA failed. Password reset aborted.");
            }
        }
        else
        {
            Console.WriteLine("Email not found.");
        }
    }

    // Hashing password using SHA256 for secure storage
    public static string HashPassword(string password)
    {
        using SHA256 sha256 = SHA256.Create();
        byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
        StringBuilder builder = new StringBuilder();
        foreach (byte b in bytes)
            builder.Append(b.ToString("x2"));
        return builder.ToString();
    }

    // Validating password format and complexity
    private bool IsValidPassword(string password)
    {
        return password.Length >= 8 &&
               Regex.IsMatch(password, @"[A-Za-z]") &&
               Regex.IsMatch(password, @"\d") &&
               Regex.IsMatch(password, @"[!@#$%^&*(),.?""{}|<>]");
    }
}

// Implementing TwoFactorAuth to generate and verify 2FA codes (Abstraction)
public class TwoFactorAuth
{
    private Random random = new Random();

    // Generating and verifying 2FA code
    public bool Verify(string email)
    {
        int code = random.Next(100000, 999999);
        Console.WriteLine($"\n2FA code sent to {email} (simulated): {code}");
        Console.Write("Enter 2FA code: ");
        
        return int.TryParse(Console.ReadLine(), out int enteredCode) && enteredCode == code;
    }
}

// Defining Program class with Main method as the entry point
public class Program
{
    public static void Main()
    {
        Bank bank = new Bank();
        bank.Start(); // Starting the application
    }
}
